// createCheckout.js
exports.handler = async (event) => {
  return { statusCode:200, body: JSON.stringify({ message: 'Integrar Stripe aquí'}) };
}